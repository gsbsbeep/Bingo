import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull(),
  password: text("password"),
  role: text("role").default("user").notNull(),
  isWaitlist: boolean("is_waitlist").default(true).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  role: true,
  isActive: true,
});

// Bingo cards schema
export const bingoCards = pgTable("bingo_cards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  cardNumbers: jsonb("card_numbers").notNull(),
  isPremium: boolean("is_premium").default(false).notNull(),
  price: integer("price").notNull(),
  purchaseDate: timestamp("purchase_date").defaultNow().notNull(),
  gameId: integer("game_id"),
  isActive: boolean("is_active").default(true).notNull(),
});

export const insertBingoCardSchema = createInsertSchema(bingoCards).omit({
  id: true,
  purchaseDate: true,
  isActive: true,
});

// Games schema
export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  status: text("status").default("pending").notNull(), // pending, in-progress, completed
  startTime: timestamp("start_time").defaultNow().notNull(),
  endTime: timestamp("end_time"),
  drawnNumbers: jsonb("drawn_numbers").default([]).notNull(),
  prizeAmount: integer("prize_amount").notNull(),
  winnerUserId: integer("winner_user_id"),
  winnerCardId: integer("winner_card_id"),
  winType: text("win_type"), // line, column, diagonal, full
});

// Estender o schema para incluir status se necessário
export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
  drawnNumbers: true,
  winnerUserId: true,
  winnerCardId: true,
  winType: true,
  endTime: true,
});

// Payments schema
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: integer("amount").notNull(),
  status: text("status").default("pending").notNull(), // pending, completed, failed
  paymentMethod: text("payment_method").default("pix").notNull(),
  paymentDate: timestamp("payment_date").defaultNow().notNull(),
  proofImageUrl: text("proof_image_url"),
  packageId: integer("package_id"),
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  status: true,
  paymentDate: true,
});

// Card packages schema
export const cardPackages = pgTable("card_packages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  cardCount: integer("card_count").notNull(),
  price: integer("price").notNull(),
  isPopular: boolean("is_popular").default(false),
  isPremium: boolean("is_premium").default(false),
});

export const insertCardPackageSchema = createInsertSchema(cardPackages).omit({
  id: true,
});

// Waitlist schema
export const waitlist = pgTable("waitlist", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull(),
  registrationDate: timestamp("registration_date").defaultNow().notNull(),
  isSubscribed: boolean("is_subscribed").default(true).notNull(),
});

export const insertWaitlistSchema = createInsertSchema(waitlist).omit({
  id: true,
  registrationDate: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type BingoCard = typeof bingoCards.$inferSelect;
export type InsertBingoCard = z.infer<typeof insertBingoCardSchema>;

export type Game = typeof games.$inferSelect;
export type InsertGame = z.infer<typeof insertGameSchema>;

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;

export type CardPackage = typeof cardPackages.$inferSelect;
export type InsertCardPackage = z.infer<typeof insertCardPackageSchema>;

export type Waitlist = typeof waitlist.$inferSelect;
export type InsertWaitlist = z.infer<typeof insertWaitlistSchema>;
