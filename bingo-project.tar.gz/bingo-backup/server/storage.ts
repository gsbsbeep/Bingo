import { 
  users, type User, type InsertUser,
  bingoCards, type BingoCard, type InsertBingoCard,
  games, type Game, type InsertGame,
  payments, type Payment, type InsertPayment,
  cardPackages, type CardPackage, type InsertCardPackage,
  waitlist, type Waitlist, type InsertWaitlist
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  listUsers(): Promise<User[]>;

  // Waitlist
  getWaitlistUser(id: number): Promise<Waitlist | undefined>;
  getWaitlistUserByEmail(email: string): Promise<Waitlist | undefined>;
  createWaitlistUser(user: InsertWaitlist): Promise<Waitlist>;
  listWaitlist(): Promise<Waitlist[]>;

  // Bingo Cards
  getBingoCard(id: number): Promise<BingoCard | undefined>;
  createBingoCard(card: InsertBingoCard): Promise<BingoCard>;
  getUserBingoCards(userId: number): Promise<BingoCard[]>;
  getGameBingoCards(gameId: number): Promise<BingoCard[]>;
  deactivateBingoCard(id: number): Promise<BingoCard | undefined>;

  // Games
  getGame(id: number): Promise<Game | undefined>;
  getActiveGame(): Promise<Game | undefined>;
  createGame(game: InsertGame): Promise<Game>;
  updateGame(id: number, game: Partial<Game>): Promise<Game | undefined>;
  listGames(): Promise<Game[]>;
  addDrawnNumber(id: number, number: number): Promise<Game | undefined>;

  // Payments
  getPayment(id: number): Promise<Payment | undefined>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePaymentStatus(id: number, status: string, proofImageUrl?: string): Promise<Payment | undefined>;
  getUserPayments(userId: number): Promise<Payment[]>;

  // Card Packages
  getCardPackage(id: number): Promise<CardPackage | undefined>;
  createCardPackage(cardPackage: InsertCardPackage): Promise<CardPackage>;
  listCardPackages(): Promise<CardPackage[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private waitlist: Map<number, Waitlist>;
  private bingoCards: Map<number, BingoCard>;
  private games: Map<number, Game>;
  private payments: Map<number, Payment>;
  private cardPackages: Map<number, CardPackage>;

  private currentUserId: number;
  private currentWaitlistId: number;
  private currentBingoCardId: number;
  private currentGameId: number;
  private currentPaymentId: number;
  private currentCardPackageId: number;

  constructor() {
    this.users = new Map();
    this.waitlist = new Map();
    this.bingoCards = new Map();
    this.games = new Map();
    this.payments = new Map();
    this.cardPackages = new Map();

    this.currentUserId = 1;
    this.currentWaitlistId = 1;
    this.currentBingoCardId = 1;
    this.currentGameId = 1;
    this.currentPaymentId = 1;
    this.currentCardPackageId = 1;

    // Initialize with demo data
    this.initializeCardPackages();
  }

  // Initialize with default card packages
  private initializeCardPackages() {
    const packages: InsertCardPackage[] = [
      { name: "Pacote Básico", cardCount: 5, price: 2000, isPopular: false, isPremium: false },
      { name: "Pacote Intermediário", cardCount: 12, price: 4000, isPopular: true, isPremium: false },
      { name: "Pacote Premium", cardCount: 25, price: 7500, isPopular: false, isPremium: true }
    ];
    
    packages.forEach(pkg => this.createCardPackage(pkg));
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      role: "user", 
      isActive: true, 
      isWaitlist: false,
      password: insertUser.password || null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async listUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Waitlist
  async getWaitlistUser(id: number): Promise<Waitlist | undefined> {
    return this.waitlist.get(id);
  }

  async getWaitlistUserByEmail(email: string): Promise<Waitlist | undefined> {
    return Array.from(this.waitlist.values()).find(
      (user) => user.email === email,
    );
  }

  async createWaitlistUser(insertWaitlist: InsertWaitlist): Promise<Waitlist> {
    const id = this.currentWaitlistId++;
    const now = new Date();
    const waitlistUser: Waitlist = { 
      ...insertWaitlist, 
      id, 
      registrationDate: now,
      isSubscribed: true
    };
    this.waitlist.set(id, waitlistUser);
    return waitlistUser;
  }

  async listWaitlist(): Promise<Waitlist[]> {
    return Array.from(this.waitlist.values());
  }

  // Bingo Cards
  async getBingoCard(id: number): Promise<BingoCard | undefined> {
    return this.bingoCards.get(id);
  }

  async createBingoCard(insertCard: InsertBingoCard): Promise<BingoCard> {
    const id = this.currentBingoCardId++;
    const now = new Date();
    const card: BingoCard = { 
      ...insertCard, 
      id, 
      purchaseDate: now,
      isActive: true,
      isPremium: insertCard.isPremium || false,
      gameId: insertCard.gameId || null
    };
    this.bingoCards.set(id, card);
    return card;
  }

  async getUserBingoCards(userId: number): Promise<BingoCard[]> {
    return Array.from(this.bingoCards.values()).filter(
      (card) => card.userId === userId && card.isActive
    );
  }

  async getGameBingoCards(gameId: number): Promise<BingoCard[]> {
    return Array.from(this.bingoCards.values()).filter(
      (card) => card.gameId === gameId && card.isActive
    );
  }

  async deactivateBingoCard(id: number): Promise<BingoCard | undefined> {
    const card = await this.getBingoCard(id);
    if (!card) return undefined;

    const updatedCard = { ...card, isActive: false };
    this.bingoCards.set(id, updatedCard);
    return updatedCard;
  }

  // Games
  async getGame(id: number): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async getActiveGame(): Promise<Game | undefined> {
    return Array.from(this.games.values()).find(
      (game) => game.status === "in-progress"
    );
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = this.currentGameId++;
    const now = new Date();
    const game: Game = { 
      ...insertGame, 
      id, 
      status: "in-progress", // Iniciar diretamente como in-progress para jogos 24h
      startTime: now,
      endTime: null,
      drawnNumbers: [],
      winnerUserId: null,
      winnerCardId: null,
      winType: null
    };
    this.games.set(id, game);
    return game;
  }

  async updateGame(id: number, gameData: Partial<Game>): Promise<Game | undefined> {
    const game = await this.getGame(id);
    if (!game) return undefined;

    const updatedGame = { ...game, ...gameData };
    this.games.set(id, updatedGame);
    return updatedGame;
  }

  async listGames(): Promise<Game[]> {
    return Array.from(this.games.values());
  }

  async addDrawnNumber(id: number, number: number): Promise<Game | undefined> {
    const game = await this.getGame(id);
    if (!game) return undefined;

    const updatedDrawnNumbers = [...game.drawnNumbers as number[], number];
    const updatedGame = { ...game, drawnNumbers: updatedDrawnNumbers };
    this.games.set(id, updatedGame);
    return updatedGame;
  }

  // Payments
  async getPayment(id: number): Promise<Payment | undefined> {
    return this.payments.get(id);
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = this.currentPaymentId++;
    const now = new Date();
    const payment: Payment = { 
      ...insertPayment, 
      id, 
      status: "pending",
      paymentDate: now,
      paymentMethod: insertPayment.paymentMethod || "pix",
      proofImageUrl: insertPayment.proofImageUrl || null,
      packageId: insertPayment.packageId || null
    };
    this.payments.set(id, payment);
    return payment;
  }

  async updatePaymentStatus(id: number, status: string, proofImageUrl?: string): Promise<Payment | undefined> {
    const payment = await this.getPayment(id);
    if (!payment) return undefined;

    const updatedPayment = { 
      ...payment, 
      status, 
      ...(proofImageUrl && { proofImageUrl })
    };
    this.payments.set(id, updatedPayment);
    return updatedPayment;
  }

  async getUserPayments(userId: number): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter(
      (payment) => payment.userId === userId
    );
  }

  // Card Packages
  async getCardPackage(id: number): Promise<CardPackage | undefined> {
    return this.cardPackages.get(id);
  }

  async createCardPackage(insertCardPackage: InsertCardPackage): Promise<CardPackage> {
    const id = this.currentCardPackageId++;
    const cardPackage: CardPackage = { 
      ...insertCardPackage, 
      id,
      isPremium: insertCardPackage.isPremium || false,
      isPopular: insertCardPackage.isPopular || false
    };
    this.cardPackages.set(id, cardPackage);
    return cardPackage;
  }

  async listCardPackages(): Promise<CardPackage[]> {
    return Array.from(this.cardPackages.values());
  }
}

export const storage = new MemStorage();
