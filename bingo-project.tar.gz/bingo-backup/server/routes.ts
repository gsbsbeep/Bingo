import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertWaitlistSchema, 
  insertBingoCardSchema,
  insertGameSchema,
  insertPaymentSchema,
  insertCardPackageSchema
} from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Middleware for admin-only routes
  const requireAdmin = async (req: Request, res: Response, next: Function) => {
    // Access user from session if we had auth
    const userId = req.query.adminId || req.body.adminId;
    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const user = await storage.getUser(Number(userId));
    if (!user || user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden: admin only" });
    }
    
    next();
  };

  // Validate Request
  const validateRequest = (schema: z.ZodSchema) => (req: Request, res: Response, next: Function) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(400).json({ message: "Invalid request data" });
      }
    }
  };

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });

  // Waitlist routes
  app.post('/api/waitlist', validateRequest(insertWaitlistSchema), async (req, res) => {
    try {
      const existingUser = await storage.getWaitlistUserByEmail(req.body.email);
      if (existingUser) {
        return res.status(409).json({ message: "Email já cadastrado na lista de espera" });
      }

      const waitlistUser = await storage.createWaitlistUser(req.body);
      res.status(201).json(waitlistUser);
    } catch (error) {
      res.status(500).json({ message: "Erro ao cadastrar na lista de espera" });
    }
  });

  app.get('/api/waitlist', requireAdmin, async (req, res) => {
    try {
      const waitlist = await storage.listWaitlist();
      res.json(waitlist);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar lista de espera" });
    }
  });

  // User routes
  app.post('/api/users', validateRequest(insertUserSchema), async (req, res) => {
    try {
      const existingUser = await storage.getUserByEmail(req.body.email);
      if (existingUser) {
        return res.status(409).json({ message: "Email já cadastrado" });
      }

      const user = await storage.createUser(req.body);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar usuário" });
    }
  });

  app.get('/api/users/:id', async (req, res) => {
    try {
      const user = await storage.getUser(Number(req.params.id));
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar usuário" });
    }
  });

  app.get('/api/users', requireAdmin, async (req, res) => {
    try {
      const users = await storage.listUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Erro ao listar usuários" });
    }
  });

  // Card Package routes
  app.get('/api/packages', async (req, res) => {
    try {
      const packages = await storage.listCardPackages();
      res.json(packages);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar pacotes de cartelas" });
    }
  });

  app.post('/api/packages', requireAdmin, validateRequest(insertCardPackageSchema), async (req, res) => {
    try {
      const cardPackage = await storage.createCardPackage(req.body);
      res.status(201).json(cardPackage);
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar pacote de cartelas" });
    }
  });

  // Payment routes
  app.post('/api/payments', validateRequest(insertPaymentSchema), async (req, res) => {
    try {
      const payment = await storage.createPayment(req.body);
      res.status(201).json(payment);
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar pagamento" });
    }
  });

  app.patch('/api/payments/:id/proof', async (req, res) => {
    try {
      const { status, proofImageUrl } = req.body;
      if (!status || !proofImageUrl) {
        return res.status(400).json({ message: "Status e comprovante são obrigatórios" });
      }

      const payment = await storage.updatePaymentStatus(
        Number(req.params.id),
        status,
        proofImageUrl
      );

      if (!payment) {
        return res.status(404).json({ message: "Pagamento não encontrado" });
      }

      res.json(payment);
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar pagamento" });
    }
  });

  app.get('/api/users/:userId/payments', async (req, res) => {
    try {
      const payments = await storage.getUserPayments(Number(req.params.userId));
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar pagamentos do usuário" });
    }
  });

  // Bingo Card routes
  app.post('/api/cards', validateRequest(insertBingoCardSchema), async (req, res) => {
    try {
      // Verificar limite de 10 cartelas por jogador
      const userId = req.body.userId;
      const userCards = await storage.getUserBingoCards(userId);
      
      if (userCards.length >= 10) {
        return res.status(400).json({ 
          message: "Limite de cartelas atingido. Você já possui 10 cartelas ativas." 
        });
      }
      
      // Verificar limite de 50 jogadores por sala
      const gameId = req.body.gameId;
      if (gameId) {
        const game = await storage.getGame(gameId);
        if (!game) {
          return res.status(404).json({ message: "Jogo não encontrado" });
        }
        
        const gameCards = await storage.getGameBingoCards(gameId);
        const uniquePlayerIds = new Set();
        
        // Contagem de jogadores únicos
        gameCards.forEach(card => uniquePlayerIds.add(card.userId));
        
        // Se o jogador atual não estiver na contagem e já temos 50 jogadores
        if (!uniquePlayerIds.has(userId) && uniquePlayerIds.size >= 50) {
          return res.status(400).json({ 
            message: "Sala de jogo cheia. Limite de 50 jogadores atingido." 
          });
        }
      }
      
      const card = await storage.createBingoCard(req.body);
      res.status(201).json(card);
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar cartela" });
    }
  });

  app.get('/api/users/:userId/cards', async (req, res) => {
    try {
      const cards = await storage.getUserBingoCards(Number(req.params.userId));
      res.json(cards);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar cartelas do usuário" });
    }
  });

  // Game routes
  app.post('/api/games', requireAdmin, validateRequest(insertGameSchema), async (req, res) => {
    try {
      // Verificar se já existe um jogo ativo
      const activeGame = await storage.getActiveGame();
      
      // Se houver um jogo ativo, não permitir criar outro
      if (activeGame && activeGame.status === "in-progress") {
        return res.status(400).json({ 
          message: "Já existe um jogo ativo. Termine o jogo atual antes de criar um novo." 
        });
      }
      
      // Criar um novo jogo para jogos 24h
      const gameData = {
        ...req.body,
        status: "in-progress", // Iniciar imediatamente para o modo 24h
        startTime: new Date()
      };
      
      const game = await storage.createGame(gameData);
      res.status(201).json(game);
    } catch (error) {
      res.status(500).json({ message: "Erro ao criar jogo" });
    }
  });

  app.get('/api/games/active', async (req, res) => {
    try {
      const game = await storage.getActiveGame();
      if (!game) {
        return res.status(404).json({ message: "Nenhum jogo ativo no momento" });
      }
      res.json(game);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar jogo ativo" });
    }
  });

  app.get('/api/games', async (req, res) => {
    try {
      const games = await storage.listGames();
      res.json(games);
    } catch (error) {
      res.status(500).json({ message: "Erro ao listar jogos" });
    }
  });

  app.get('/api/games/:id', async (req, res) => {
    try {
      const game = await storage.getGame(Number(req.params.id));
      if (!game) {
        return res.status(404).json({ message: "Jogo não encontrado" });
      }
      res.json(game);
    } catch (error) {
      res.status(500).json({ message: "Erro ao buscar jogo" });
    }
  });

  app.patch('/api/games/:id/status', requireAdmin, async (req, res) => {
    try {
      const { status } = req.body;
      if (!status) {
        return res.status(400).json({ message: "Status é obrigatório" });
      }

      const game = await storage.updateGame(Number(req.params.id), { status });
      if (!game) {
        return res.status(404).json({ message: "Jogo não encontrado" });
      }

      res.json(game);
    } catch (error) {
      res.status(500).json({ message: "Erro ao atualizar status do jogo" });
    }
  });

  app.post('/api/games/:id/draw', requireAdmin, async (req, res) => {
    try {
      const { number } = req.body;
      if (number === undefined || number === null) {
        return res.status(400).json({ message: "Número é obrigatório" });
      }

      const game = await storage.getGame(Number(req.params.id));
      if (!game) {
        return res.status(404).json({ message: "Jogo não encontrado" });
      }

      if (game.status !== "in-progress") {
        return res.status(400).json({ message: "O jogo não está em andamento" });
      }

      // Check if the number was already drawn
      const drawnNumbers = game.drawnNumbers as number[];
      if (drawnNumbers.includes(number)) {
        return res.status(400).json({ message: "Este número já foi sorteado" });
      }

      const updatedGame = await storage.addDrawnNumber(Number(req.params.id), number);
      res.json(updatedGame);
    } catch (error) {
      res.status(500).json({ message: "Erro ao sortear número" });
    }
  });

  app.post('/api/games/:id/winner', requireAdmin, async (req, res) => {
    try {
      const { winnerUserId, winnerCardId, winType } = req.body;
      if (!winnerUserId || !winnerCardId || !winType) {
        return res.status(400).json({ message: "Dados do vencedor são obrigatórios" });
      }

      const now = new Date();
      const gameId = Number(req.params.id);
      
      // Obter o jogo atual para usar suas informações
      const currentGame = await storage.getGame(gameId);
      if (!currentGame) {
        return res.status(404).json({ message: "Jogo não encontrado" });
      }
      
      // Finalizar o jogo atual
      const game = await storage.updateGame(gameId, { 
        winnerUserId, 
        winnerCardId, 
        winType,
        status: "completed",
        endTime: now
      });

      if (!game) {
        return res.status(404).json({ message: "Erro ao atualizar o jogo" });
      }
      
      // Criar automaticamente um novo jogo para manter o ciclo 24/7
      // Usar o mesmo nome, mas incrementar o acumulado se aplicável
      let newPrizeAmount = currentGame.prizeAmount;
      
      // Se for um prêmio acumulado e ninguém ganhou o acumulado, incrementa o valor
      if (winType !== "complete-card") {
        // Aumentar o prêmio acumulado em R$50
        newPrizeAmount += 5000; // 50 reais em centavos
      }
      
      // Criar novo jogo automaticamente
      const newGame = await storage.createGame({
        name: currentGame.name,
        prizeAmount: newPrizeAmount,
        startTime: new Date()
      });
      
      // Responder com o jogo finalizado e informações sobre o novo jogo
      res.json({
        completedGame: game,
        newGame: newGame,
        message: "Jogo finalizado com sucesso. Novo jogo iniciado automaticamente."
      });
    } catch (error) {
      res.status(500).json({ message: "Erro ao registrar vencedor" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
