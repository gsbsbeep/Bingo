import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import BingoBall from "@/components/BingoBall";
import { useGameContext } from "@/context/GameContext";
import { getNextBingoBall, formatPrice } from "@/lib/bingoUtils";

import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, Trophy, Users } from "lucide-react";

// Mock admin ID for demo purposes
const ADMIN_ID = 1;

export default function AdminPage() {
  const { toast } = useToast();
  const { drawnNumbers, setDrawnNumbers, setLastDrawnNumber } = useGameContext();
  const [prizeName, setPrizeName] = useState("Bingo Especial");
  const [prizeAmount, setPrizeAmount] = useState(20000); // R$ 200,00
  const [isCreatingGame, setIsCreatingGame] = useState(false);
  const [drawInterval, setDrawInterval] = useState<number | null>(null);
  const [countdownValue, setCountdownValue] = useState(10);

  // Get active game if any
  const { 
    data: activeGame, 
    isLoading: isLoadingGame,
    refetch: refetchActiveGame
  } = useQuery({
    queryKey: ['/api/games/active'],
  });

  // Get waitlist
  const { 
    data: waitlist, 
    isLoading: isLoadingWaitlist 
  } = useQuery({
    queryKey: ['/api/waitlist', { adminId: ADMIN_ID }],
  });

  // Get users
  const { 
    data: users, 
    isLoading: isLoadingUsers 
  } = useQuery({
    queryKey: ['/api/users', { adminId: ADMIN_ID }],
  });

  // Create a new game
  const createGameMutation = useMutation({
    mutationFn: async (gameData: any) => {
      const response = await apiRequest("POST", "/api/games", {
        ...gameData,
        adminId: ADMIN_ID
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Jogo criado com sucesso",
        description: "O novo jogo está pronto para começar!",
        variant: "success",
      });
      refetchActiveGame();
      setIsCreatingGame(false);
    },
    onError: (error) => {
      toast({
        title: "Erro ao criar jogo",
        description: error.toString(),
        variant: "destructive",
      });
      setIsCreatingGame(false);
    },
  });

  // Update game status
  const updateGameStatusMutation = useMutation({
    mutationFn: async ({ gameId, status }: { gameId: number, status: string }) => {
      const response = await apiRequest("PATCH", `/api/games/${gameId}/status`, {
        status,
        adminId: ADMIN_ID
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Status do jogo atualizado",
        description: "O status do jogo foi atualizado com sucesso!",
        variant: "success",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/games/active'] });
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar status do jogo",
        description: error.toString(),
        variant: "destructive",
      });
    },
  });

  // Draw a new number
  const drawNumberMutation = useMutation({
    mutationFn: async ({ gameId, number }: { gameId: number, number: number }) => {
      const response = await apiRequest("POST", `/api/games/${gameId}/draw`, {
        number,
        adminId: ADMIN_ID
      });
      return response.json();
    },
    onSuccess: (data) => {
      const updatedDrawnNumbers = data.drawnNumbers;
      setDrawnNumbers(updatedDrawnNumbers);
      setLastDrawnNumber(updatedDrawnNumbers[updatedDrawnNumbers.length - 1]);
      refetchActiveGame();
      setCountdownValue(10); // Reset countdown
      
      toast({
        title: "Número sorteado",
        description: `Bola ${updatedDrawnNumbers[updatedDrawnNumbers.length - 1]} foi sorteada!`,
        variant: "success",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao sortear número",
        description: error.toString(),
        variant: "destructive",
      });
    },
  });

  // Declare a winner
  const declareWinnerMutation = useMutation({
    mutationFn: async ({ 
      gameId, 
      winnerUserId, 
      winnerCardId, 
      winType 
    }: { 
      gameId: number, 
      winnerUserId: number, 
      winnerCardId: number, 
      winType: string 
    }) => {
      const response = await apiRequest("POST", `/api/games/${gameId}/winner`, {
        winnerUserId,
        winnerCardId,
        winType,
        adminId: ADMIN_ID
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Vencedor declarado!",
        description: "O jogo foi finalizado com sucesso!",
        variant: "success",
      });
      stopAutoDraw();
      queryClient.invalidateQueries({ queryKey: ['/api/games/active'] });
    },
    onError: (error) => {
      toast({
        title: "Erro ao declarar vencedor",
        description: error.toString(),
        variant: "destructive",
      });
    },
  });

  // Handle creating a new game
  const handleCreateGame = () => {
    setIsCreatingGame(true);
    createGameMutation.mutate({
      name: prizeName,
      prizeAmount: prizeAmount,
      startTime: new Date()
    });
  };

  // Handle starting the game
  const handleStartGame = () => {
    if (!activeGame) return;
    
    updateGameStatusMutation.mutate({
      gameId: activeGame.id,
      status: "in-progress"
    });
  };

  // Handle stopping the game
  const handleStopGame = () => {
    if (!activeGame) return;
    
    stopAutoDraw();
    updateGameStatusMutation.mutate({
      gameId: activeGame.id,
      status: "completed"
    });
  };

  // Handle drawing a number manually
  const handleDrawNumber = () => {
    if (!activeGame) return;
    
    const newNumber = getNextBingoBall(drawnNumbers);
    drawNumberMutation.mutate({
      gameId: activeGame.id,
      number: newNumber
    });
  };

  // Start automatic drawing
  const startAutoDraw = () => {
    if (drawInterval) {
      clearInterval(drawInterval);
    }
    
    // Set countdown timer
    let countdown = 10;
    setCountdownValue(countdown);
    
    const interval = window.setInterval(() => {
      setCountdownValue(prev => {
        if (prev <= 1) {
          // Time to draw a new number
          if (activeGame && activeGame.status === "in-progress") {
            const newNumber = getNextBingoBall(drawnNumbers);
            drawNumberMutation.mutate({
              gameId: activeGame.id,
              number: newNumber
            });
          }
          return 10; // Reset countdown
        }
        return prev - 1;
      });
    }, 1000);
    
    setDrawInterval(interval);
    
    toast({
      title: "Sorteio automático iniciado",
      description: "Números serão sorteados a cada 10 segundos.",
      variant: "success",
    });
  };

  // Stop automatic drawing
  const stopAutoDraw = () => {
    if (drawInterval) {
      clearInterval(drawInterval);
      setDrawInterval(null);
      
      toast({
        title: "Sorteio automático interrompido",
        description: "O sorteio automático foi interrompido.",
        variant: "default",
      });
    }
  };

  // Mock function to declare a winner (in a real app this would validate the winning condition)
  const handleDeclareWinner = () => {
    if (!activeGame) return;
    
    // For demo purposes, we're using mock data
    declareWinnerMutation.mutate({
      gameId: activeGame.id,
      winnerUserId: 1,
      winnerCardId: 1,
      winType: "line"
    });
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (drawInterval) {
        clearInterval(drawInterval);
      }
    };
  }, [drawInterval]);

  // Reset drawn numbers when a new game starts
  useEffect(() => {
    if (activeGame && activeGame.status === "pending") {
      setDrawnNumbers([]);
      setLastDrawnNumber(null);
    } else if (activeGame && activeGame.drawnNumbers) {
      setDrawnNumbers(activeGame.drawnNumbers);
      if (activeGame.drawnNumbers.length > 0) {
        setLastDrawnNumber(activeGame.drawnNumbers[activeGame.drawnNumbers.length - 1]);
      }
    }
  }, [activeGame]);

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-primary text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <span className="material-icons">admin_panel_settings</span>
            <h1 className="text-xl font-bold">Painel do Administrador - Bingo Gipsy</h1>
          </div>
          <div>
            <Badge className="bg-accent text-neutral-dark">Administrador</Badge>
          </div>
        </div>
      </header>

      <main className="container mx-auto p-4">
        <Tabs defaultValue="game">
          <TabsList className="mb-6">
            <TabsTrigger value="game">Gerenciar Jogo</TabsTrigger>
            <TabsTrigger value="users">Usuários</TabsTrigger>
            <TabsTrigger value="waitlist">Lista de Espera</TabsTrigger>
            <TabsTrigger value="settings">Configurações</TabsTrigger>
          </TabsList>

          <TabsContent value="game">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Controle do Jogo</CardTitle>
                  <CardDescription>
                    {activeGame ? (
                      `Jogo #${activeGame.id} - ${activeGame.name}`
                    ) : (
                      "Nenhum jogo ativo no momento"
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {!activeGame ? (
                    <div className="space-y-4">
                      <Alert>
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Nenhum jogo ativo</AlertTitle>
                        <AlertDescription>
                          Crie um novo jogo para começar o sorteio.
                        </AlertDescription>
                      </Alert>
                      
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label htmlFor="prizeName" className="text-sm font-medium">
                              Nome do Prêmio
                            </label>
                            <Input
                              id="prizeName"
                              value={prizeName}
                              onChange={(e) => setPrizeName(e.target.value)}
                              placeholder="Nome do prêmio"
                            />
                          </div>
                          <div className="space-y-2">
                            <label htmlFor="prizeAmount" className="text-sm font-medium">
                              Valor do Prêmio (em centavos)
                            </label>
                            <Input
                              id="prizeAmount"
                              type="number"
                              value={prizeAmount}
                              onChange={(e) => setPrizeAmount(Number(e.target.value))}
                              placeholder="Valor em centavos"
                            />
                          </div>
                        </div>
                        <Button 
                          onClick={handleCreateGame} 
                          disabled={isCreatingGame}
                          className="w-full"
                        >
                          {isCreatingGame ? "Criando..." : "Criar Novo Jogo"}
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="flex justify-between items-center">
                        <div>
                          <h3 className="text-lg font-semibold">
                            Status: {" "}
                            <Badge variant={activeGame.status === "in-progress" ? "success" : "secondary"}>
                              {activeGame.status === "pending"
                                ? "Aguardando Início"
                                : activeGame.status === "in-progress"
                                ? "Em Andamento"
                                : "Finalizado"}
                            </Badge>
                          </h3>
                          <p className="text-sm text-gray-500">
                            Prêmio: {formatPrice(activeGame.prizeAmount)}
                          </p>
                        </div>
                        
                        <div className="flex space-x-2">
                          {activeGame.status === "pending" && (
                            <Button onClick={handleStartGame} variant="success">
                              Iniciar Jogo
                            </Button>
                          )}
                          
                          {activeGame.status === "in-progress" && (
                            <Button onClick={handleStopGame} variant="destructive">
                              Finalizar Jogo
                            </Button>
                          )}
                        </div>
                      </div>
                      
                      <Separator />
                      
                      {activeGame.status === "in-progress" && (
                        <div className="space-y-6">
                          <div className="text-center">
                            <h3 className="text-lg font-semibold mb-2">Último número sorteado:</h3>
                            <div className="flex justify-center">
                              {drawnNumbers.length > 0 ? (
                                <BingoBall 
                                  number={drawnNumbers[drawnNumbers.length - 1]} 
                                  size="lg" 
                                  pulse={true}
                                />
                              ) : (
                                <div className="text-center p-4 bg-gray-100 rounded-full w-24 h-24 flex items-center justify-center">
                                  <span className="text-gray-500">-</span>
                                </div>
                              )}
                            </div>
                            
                            <div className="mt-4">
                              <p className="text-sm text-gray-500 mb-2">Próximo sorteio em:</p>
                              <span className="text-2xl font-bold">{countdownValue}s</span>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <Button 
                              onClick={handleDrawNumber}
                              disabled={!!drawInterval}
                            >
                              Sortear Manualmente
                            </Button>
                            
                            {drawInterval ? (
                              <Button 
                                onClick={stopAutoDraw}
                                variant="destructive"
                              >
                                Parar Sorteio Automático
                              </Button>
                            ) : (
                              <Button 
                                onClick={startAutoDraw}
                                variant="secondary"
                              >
                                Iniciar Sorteio Automático
                              </Button>
                            )}
                          </div>
                          
                          <Button 
                            onClick={handleDeclareWinner}
                            variant="success"
                            className="w-full"
                          >
                            <Trophy className="mr-2 h-4 w-4" />
                            Declarar Vencedor
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Números Sorteados</CardTitle>
                  <CardDescription>
                    {drawnNumbers.length} de 75 bolas sorteadas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {drawnNumbers.length > 0 ? (
                      drawnNumbers.map(number => (
                        <BingoBall key={number} number={number} size="sm" />
                      ))
                    ) : (
                      <div className="text-center p-4">
                        <span className="text-gray-500">Nenhum número sorteado</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>Gerenciar Usuários</CardTitle>
                <CardDescription>
                  {users?.length || 0} usuários cadastrados no sistema
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingUsers ? (
                  <div className="text-center py-4">Carregando usuários...</div>
                ) : (
                  <Table>
                    <TableCaption>Lista de usuários cadastrados</TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Nome</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Telefone</TableHead>
                        <TableHead>Papel</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users?.map((user: any) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">#{user.id}</TableCell>
                          <TableCell>{user.name}</TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>{user.phone}</TableCell>
                          <TableCell>
                            <Badge variant={user.role === "admin" ? "secondary" : "outline"}>
                              {user.role === "admin" ? "Admin" : "Usuário"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={user.isActive ? "success" : "destructive"}>
                              {user.isActive ? "Ativo" : "Inativo"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="waitlist">
            <Card>
              <CardHeader>
                <CardTitle>Lista de Espera</CardTitle>
                <CardDescription>
                  {waitlist?.length || 0} pessoas na lista de espera
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingWaitlist ? (
                  <div className="text-center py-4">Carregando lista de espera...</div>
                ) : (
                  <Table>
                    <TableCaption>Lista de pessoas interessadas no lançamento</TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Nome</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Telefone</TableHead>
                        <TableHead>Data de Registro</TableHead>
                        <TableHead>Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {waitlist?.map((user: any) => (
                        <TableRow key={user.id}>
                          <TableCell className="font-medium">#{user.id}</TableCell>
                          <TableCell>{user.name}</TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>{user.phone}</TableCell>
                          <TableCell>{new Date(user.registrationDate).toLocaleString('pt-BR')}</TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm">
                              Enviar Email
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Configurações</CardTitle>
                <CardDescription>
                  Configurações do sistema de bingo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="pixKey" className="text-sm font-medium">
                        Chave PIX
                      </label>
                      <Input
                        id="pixKey"
                        value="gabrielastefa1@gmail.com"
                        readOnly
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="autoDrawInterval" className="text-sm font-medium">
                        Intervalo de Sorteio Automático (segundos)
                      </label>
                      <Input
                        id="autoDrawInterval"
                        type="number"
                        value="10"
                        min="5"
                        max="30"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="siteStatus" className="text-sm font-medium">
                      Status do Site
                    </label>
                    <select
                      id="siteStatus"
                      className="w-full p-2 border border-input rounded-md"
                      defaultValue="waitlist"
                    >
                      <option value="waitlist">Modo Lista de Espera</option>
                      <option value="live">Modo Ao Vivo</option>
                      <option value="maintenance">Manutenção</option>
                    </select>
                  </div>
                  
                  <Button className="w-full">
                    Salvar Configurações
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
