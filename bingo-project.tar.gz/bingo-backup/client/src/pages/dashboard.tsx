import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import BingoCard from "@/components/BingoCard";
import BingoBall from "@/components/BingoBall";
import { useGameContext } from "@/context/GameContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { formatPrice } from "@/lib/bingoUtils";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [match, params] = useRoute("/dashboard/:userId");
  const { drawnNumbers, lastDrawnNumber } = useGameContext();
  const userId = match ? Number(params?.userId) : null;

  // Fetch user data
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });

  // Fetch user's cards
  const { data: cards, isLoading: isLoadingCards } = useQuery({
    queryKey: [`/api/users/${userId}/cards`],
    enabled: !!userId,
  });

  // Fetch active game
  const { data: activeGame, isLoading: isLoadingGame } = useQuery({
    queryKey: ['/api/games/active'],
  });

  // Fetch user's payments
  const { data: payments, isLoading: isLoadingPayments } = useQuery({
    queryKey: [`/api/users/${userId}/payments`],
    enabled: !!userId,
  });

  // Fetch available packages
  const { data: packages, isLoading: isLoadingPackages } = useQuery({
    queryKey: ['/api/packages'],
  });

  // Handle buying a package
  const handleBuyPackage = (packageId: number) => {
    if (!userId) return;
    navigate(`/payment/${userId}/${packageId}`);
  };

  if (!userId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Acesso não autorizado</CardTitle>
            <CardDescription>
              Você não tem permissão para visualizar esta página.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button className="w-full" onClick={() => navigate("/")}>
              Voltar para a página inicial
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isLoadingUser || isLoadingCards || isLoadingGame || isLoadingPayments || isLoadingPackages) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-lg">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-background min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-heading font-bold">Olá, {user?.name}</h1>
            <p className="text-gray-600">Bem-vindo ao seu painel de bingo</p>
          </div>
          
          <div className="flex items-center space-x-2 mt-4 md:mt-0">
            <Badge variant="outline" className="text-md font-medium px-3 py-1">
              {cards?.length || 0} Cartelas
            </Badge>
            <Badge variant="secondary" className="text-md font-medium px-3 py-1">
              ID: #{userId}
            </Badge>
          </div>
        </div>

        <Tabs defaultValue="game" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="game">Jogo Atual</TabsTrigger>
            <TabsTrigger value="cards">Minhas Cartelas</TabsTrigger>
            <TabsTrigger value="history">Histórico</TabsTrigger>
            <TabsTrigger value="buy">Comprar Cartelas</TabsTrigger>
          </TabsList>
          
          <TabsContent value="game">
            <Card>
              <CardHeader>
                <CardTitle className="flex justify-between items-center">
                  <span>Bingo em Andamento</span>
                  {activeGame ? (
                    <Badge className="bg-success animate-pulse">{activeGame.status === "in-progress" ? "Ao Vivo" : "Aguardando"}</Badge>
                  ) : (
                    <Badge className="bg-secondary">Nenhum jogo ativo</Badge>
                  )}
                </CardTitle>
                <CardDescription>
                  {activeGame ? 
                    `Jogo #${activeGame.id} - Prêmio: ${formatPrice(activeGame.prizeAmount)}` : 
                    "Não há jogo em andamento no momento. Fique atento para o próximo!"
                  }
                </CardDescription>
              </CardHeader>
              <CardContent>
                {activeGame && activeGame.status === "in-progress" ? (
                  <>
                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-3">Último número sorteado:</h3>
                      <div className="flex justify-center">
                        {lastDrawnNumber ? (
                          <BingoBall 
                            number={lastDrawnNumber} 
                            size="lg" 
                            pulse={true}
                          />
                        ) : (
                          <div className="text-center text-gray-500">
                            Aguardando sorteio...
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Números já sorteados:</h3>
                      <div className="flex flex-wrap gap-2 justify-center">
                        {drawnNumbers.length > 0 ? (
                          drawnNumbers.map(number => (
                            <BingoBall key={number} number={number} size="sm" />
                          ))
                        ) : (
                          <div className="text-center text-gray-500">
                            Nenhum número sorteado ainda
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <div className="material-icons text-gray-400 text-6xl mb-4">schedule</div>
                    <h3 className="text-xl font-semibold mb-2">Próximo jogo em breve</h3>
                    <p className="text-gray-500">Fique atento às notificações para participar do próximo sorteio.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="cards">
            <Card>
              <CardHeader>
                <CardTitle>Minhas Cartelas</CardTitle>
                <CardDescription>
                  Você possui {cards?.length || 0} cartelas ativas.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {cards && cards.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {cards.map((card: any) => (
                      <BingoCard
                        key={card.id}
                        cardId={`#${card.id}`}
                        numbers={card.cardNumbers}
                        markedNumbers={drawnNumbers}
                        isPremium={card.isPremium}
                        price={card.price}
                        showPrice={false}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <div className="material-icons text-gray-400 text-6xl mb-4">content_paste_off</div>
                    <h3 className="text-xl font-semibold mb-2">Nenhuma cartela encontrada</h3>
                    <p className="text-gray-500 mb-4">Você ainda não possui cartelas de bingo.</p>
                    <Button onClick={() => document.getElementById('buy-tab')?.click()}>
                      Comprar Cartelas
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Histórico de Pagamentos</CardTitle>
                <CardDescription>
                  Seus pagamentos e compras recentes.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {payments && payments.length > 0 ? (
                  <Table>
                    <TableCaption>Lista de pagamentos recentes</TableCaption>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Data</TableHead>
                        <TableHead>Valor</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Método</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {payments.map((payment: any) => (
                        <TableRow key={payment.id}>
                          <TableCell className="font-medium">#{payment.id}</TableCell>
                          <TableCell>{new Date(payment.paymentDate).toLocaleString('pt-BR')}</TableCell>
                          <TableCell>{formatPrice(payment.amount)}</TableCell>
                          <TableCell>
                            <Badge 
                              variant={
                                payment.status === "completed" ? "success" : 
                                payment.status === "pending" ? "warning" : "destructive"
                              }
                            >
                              {payment.status === "completed" ? "Aprovado" : 
                               payment.status === "pending" ? "Pendente" : "Falhou"}
                            </Badge>
                          </TableCell>
                          <TableCell>PIX</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <div className="material-icons text-gray-400 text-6xl mb-4">history</div>
                    <h3 className="text-xl font-semibold mb-2">Nenhum pagamento encontrado</h3>
                    <p className="text-gray-500">Você ainda não realizou nenhum pagamento.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="buy" id="buy-tab">
            <Card>
              <CardHeader>
                <CardTitle>Comprar Cartelas</CardTitle>
                <CardDescription>
                  Escolha um pacote de cartelas para participar dos jogos.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {packages && packages.map((pkg: any) => (
                    <div 
                      key={pkg.id} 
                      className={`bg-white p-6 rounded-lg shadow-md border ${pkg.isPopular ? 'border-2 border-secondary' : 'border-gray-200'}`}
                    >
                      {pkg.isPopular && (
                        <div className="bg-secondary text-white px-3 py-1 rounded-full text-xs font-bold inline-block -mt-10 mb-2">
                          MAIS POPULAR
                        </div>
                      )}
                      <h3 className="font-heading font-bold text-xl mb-3">{pkg.name}</h3>
                      <p className="text-3xl font-bold text-primary mb-3">{formatPrice(pkg.price)}</p>
                      <p className="text-gray-600 mb-4">
                        {pkg.cardCount} cartelas ({formatPrice(pkg.price / pkg.cardCount)} cada)
                      </p>
                      <ul className="space-y-2 mb-6">
                        <li className="flex items-start">
                          <span className="material-icons text-success mr-2 text-sm mt-1">check_circle</span>
                          <span className="text-sm">{pkg.cardCount} cartelas de bingo</span>
                        </li>
                        {pkg.isPremium && (
                          <li className="flex items-start">
                            <span className="material-icons text-success mr-2 text-sm mt-1">check_circle</span>
                            <span className="text-sm">Inclui cartelas premium</span>
                          </li>
                        )}
                        <li className="flex items-start">
                          <span className="material-icons text-success mr-2 text-sm mt-1">check_circle</span>
                          <span className="text-sm">Válido para todos os jogos</span>
                        </li>
                      </ul>
                      <Button 
                        className={`w-full ${pkg.isPopular ? 'bg-secondary hover:bg-blue-600' : ''}`}
                        onClick={() => handleBuyPackage(pkg.id)}
                      >
                        Comprar Agora
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <Footer />
    </div>
  );
}
