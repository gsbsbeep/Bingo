import { useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import PixPayment from "@/components/pix-payment";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { formatPrice } from "@/lib/bingoUtils";
import { CheckCircle, AlertCircle } from "lucide-react";

export default function PaymentPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [match, params] = useRoute("/payment/:userId/:packageId");
  const userId = match ? Number(params?.userId) : null;
  const packageId = match ? Number(params?.packageId) : null;
  const [paymentStatus, setPaymentStatus] = useState<"pending" | "processing" | "completed" | "failed">("pending");
  const [paymentId, setPaymentId] = useState<number | null>(null);

  // Fetch user data
  const { data: user, isLoading: isLoadingUser } = useQuery({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });

  // Fetch package data
  const { data: cardPackage, isLoading: isLoadingPackage } = useQuery({
    queryKey: [`/api/packages`],
    enabled: !!packageId,
    select: (data) => data.find((pkg: any) => pkg.id === packageId),
  });

  // Create payment mutation
  const createPaymentMutation = useMutation({
    mutationFn: async (paymentData: any) => {
      const response = await apiRequest("POST", "/api/payments", paymentData);
      return response.json();
    },
    onSuccess: (data) => {
      setPaymentId(data.id);
      toast({
        title: "Pagamento criado",
        description: "Seu pagamento foi registrado. Complete a transferência PIX.",
        variant: "success",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro ao criar pagamento",
        description: error.toString(),
        variant: "destructive",
      });
    },
  });

  // Submit payment proof
  const submitProofMutation = useMutation({
    mutationFn: async ({ paymentId, proofUrl }: { paymentId: number, proofUrl: string }) => {
      const response = await apiRequest("PATCH", `/api/payments/${paymentId}/proof`, {
        status: "completed",
        proofImageUrl: proofUrl
      });
      return response.json();
    },
    onSuccess: () => {
      setPaymentStatus("completed");
      toast({
        title: "Comprovante enviado",
        description: "Seu comprovante foi enviado com sucesso e está em análise.",
        variant: "success",
      });
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/payments`] });
      
      // In a real app, we would wait for approval
      // For the demo, we'll simulate approval after 3 seconds
      setTimeout(() => {
        toast({
          title: "Pagamento aprovado",
          description: "Suas cartelas foram liberadas com sucesso!",
          variant: "success",
        });
      }, 3000);
    },
    onError: (error) => {
      setPaymentStatus("failed");
      toast({
        title: "Erro ao enviar comprovante",
        description: error.toString(),
        variant: "destructive",
      });
    },
  });

  // Handle submitting payment proof
  const handleProofSubmit = (proofUrl: string) => {
    if (!paymentId) {
      toast({
        title: "Erro",
        description: "ID de pagamento não encontrado",
        variant: "destructive",
      });
      return;
    }
    
    setPaymentStatus("processing");
    submitProofMutation.mutate({ paymentId, proofUrl });
  };

  // Initialize payment
  const initializePayment = () => {
    if (!userId || !packageId || !cardPackage) return;
    
    createPaymentMutation.mutate({
      userId,
      amount: cardPackage.price,
      packageId
    });
  };

  // Complete purchase and return to dashboard
  const handleCompletePurchase = () => {
    navigate(`/dashboard/${userId}`);
  };

  // If there's no payment ID yet, initialize the payment
  // In a real app, we would check if there's an existing pending payment
  if (!paymentId && !createPaymentMutation.isPending && cardPackage && userId) {
    initializePayment();
  }

  if (isLoadingUser || isLoadingPackage) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-lg">Carregando informações de pagamento...</p>
        </div>
      </div>
    );
  }

  if (!cardPackage || !userId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Erro de Pagamento</CardTitle>
            <CardDescription>
              Não foi possível encontrar as informações do pacote ou usuário.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Parâmetros inválidos</AlertTitle>
              <AlertDescription>
                As informações necessárias para o pagamento estão incompletas.
              </AlertDescription>
            </Alert>
            <Button 
              className="w-full" 
              onClick={() => navigate("/")}
            >
              Voltar para a página inicial
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="bg-background min-h-screen flex flex-col">
      <Navbar />

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Pagamento via PIX</CardTitle>
              <CardDescription>
                Complete seu pagamento para adquirir o pacote de cartelas.
              </CardDescription>
            </CardHeader>

            <CardContent>
              {paymentStatus === "completed" ? (
                <div className="text-center py-8">
                  <div className="bg-success/20 p-6 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="h-12 w-12 text-success" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">Pagamento Concluído!</h2>
                  <p className="text-gray-600 mb-6">
                    Seu pagamento foi registrado com sucesso e suas cartelas foram liberadas.
                  </p>
                  <Button 
                    size="lg" 
                    onClick={handleCompletePurchase}
                  >
                    Ver Minhas Cartelas
                  </Button>
                </div>
              ) : (
                <>
                  <div className="mb-6 p-4 bg-neutral-50 rounded-lg">
                    <h3 className="font-semibold text-lg mb-2">Resumo da compra</h3>
                    <div className="flex justify-between mb-2">
                      <span>Pacote:</span>
                      <span className="font-medium">{cardPackage.name}</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span>Quantidade de cartelas:</span>
                      <span className="font-medium">{cardPackage.cardCount} cartelas</span>
                    </div>
                    <div className="flex justify-between mb-2">
                      <span>Preço unitário:</span>
                      <span className="font-medium">
                        {formatPrice(cardPackage.price / cardPackage.cardCount)}
                      </span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span className="text-primary">{formatPrice(cardPackage.price)}</span>
                    </div>
                  </div>

                  <Tabs defaultValue="pix">
                    <TabsList className="grid grid-cols-1 mb-6">
                      <TabsTrigger value="pix">PIX</TabsTrigger>
                    </TabsList>
                    <TabsContent value="pix">
                      <PixPayment 
                        pixKey="gabrielastefa1@gmail.com" 
                        amount={cardPackage.price}
                        onProofSubmit={handleProofSubmit}
                        status={paymentStatus}
                      />
                    </TabsContent>
                  </Tabs>
                </>
              )}
            </CardContent>

            <CardFooter className="flex flex-col space-y-4">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Importante</AlertTitle>
                <AlertDescription>
                  Após realizar o pagamento, envie o comprovante para liberação das cartelas.
                  Em caso de dúvidas, entre em contato pelo email: gabrielastefa1@gmail.com
                </AlertDescription>
              </Alert>
              
              {paymentStatus !== "completed" && (
                <Button 
                  variant="outline" 
                  className="w-full" 
                  onClick={() => navigate(`/dashboard/${userId}`)}
                >
                  Cancelar pagamento
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
