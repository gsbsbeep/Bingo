import { useState } from "react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/navbar";
import Footer from "@/components/footer";
import RegisterForm from "@/components/waitlist-form";
import GameRules from "@/components/game-rules";
import BingoCard from "@/components/BingoCard";
import BingoBall from "@/components/BingoBall";
import Testimonials from "@/components/testimonials";
import { CardPackage } from "@shared/schema";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function HomePage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Fetch packages
  const { data: packages = [], isLoading: isLoadingPackages } = useQuery({
    queryKey: ['/api/packages'],
  });
  
  // Demo cards for display
  const demoCards = [
    {
      id: "demo1",
      cardNumbers: [
        [3, 14, 5, 12, 7],
        [18, 29, 16, 24, 21],
        [43, 35, 0, 44, 37],
        [52, 47, 59, 48, 51],
        [63, 69, 65, 72, 75]
      ],
      markedNumbers: [12, 29, 37, 59, 69]
    },
    {
      id: "demo2",
      cardNumbers: [
        [2, 9, 4, 15, 11],
        [17, 25, 22, 28, 19],
        [40, 33, 0, 38, 32],
        [56, 49, 57, 54, 46],
        [61, 70, 68, 71, 64]
      ],
      markedNumbers: [9, 22, 40, 49, 68]
    },
    {
      id: "demo3",
      cardNumbers: [
        [6, 13, 1, 10, 8],
        [30, 23, 16, 27, 20],
        [36, 39, 0, 42, 31],
        [53, 45, 58, 55, 50],
        [67, 74, 62, 73, 66]
      ],
      isPremium: true,
      markedNumbers: [1, 30, 39, 55, 73]
    }
  ];

  // Demo drawn balls
  const demoBalls = [18, 34, 52, 7, 63];
  
  // Handle package purchase
  const handleBuyPackage = (pkg: CardPackage) => {
    toast({
      title: "Para comprar este pacote",
      description: "É necessário fazer cadastro ou login.",
      variant: "default",
    });
  };
  
  return (
    <div className="bg-background min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative py-16 md:py-24 bg-neutral-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1606167668584-78701c57f13d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80')] bg-cover bg-center opacity-20"></div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <div className="max-w-3xl mx-auto">
            <div className="flex justify-center space-x-2 mb-8">
              {/* Bingo balls animation */}
              <BingoBall letter="B" number={7} animationDelay={0} />
              <BingoBall letter="I" number={22} animationDelay={0.2} />
              <BingoBall letter="N" number={42} animationDelay={0.4} />
              <BingoBall letter="G" number={56} animationDelay={0.6} />
              <BingoBall letter="O" number={68} animationDelay={0.8} />
            </div>
            <h1 className="text-4xl md:text-5xl font-heading font-bold text-white mb-6">
              O Melhor Bingo Online do Brasil!
            </h1>
            <p className="text-lg md:text-xl text-white mb-8">
              Diversão, prêmios e emoção diretamente do conforto da sua casa.
            </p>
            <a 
              href="#cadastro" 
              className="bg-accent text-neutral-dark hover:bg-yellow-400 font-bold py-3 px-8 rounded-full text-lg transition-colors shadow-lg inline-flex items-center"
            >
              <span className="material-icons mr-2">emoji_events</span>
              Crie sua Conta e Jogue Agora
            </a>
          </div>
        </div>
      </section>
      
      {/* Game Rules Section */}
      <GameRules />
      
      {/* Bingo Cards Section */}
      <section id="cartelas" className="py-16 bg-neutral-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-neutral-dark mb-4">
              Cartelas de Bingo
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Nossas cartelas são geradas digitalmente com números aleatórios. Compre quantas quiser para aumentar suas chances!
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {demoCards.map((card, index) => (
              <BingoCard 
                key={card.id}
                cardId={`#${12345 + index}`}
                numbers={card.cardNumbers}
                markedNumbers={card.markedNumbers}
                isPremium={card.isPremium}
                price={card.isPremium ? 1000 : 500}
              />
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <p className="text-lg mb-6">Compre pacotes de cartelas com desconto!</p>
            <div className="flex flex-wrap justify-center gap-4">
              {isLoadingPackages ? (
                <div className="text-center">Carregando pacotes...</div>
              ) : (
                packages?.map((pkg: CardPackage) => (
                  <div 
                    key={pkg.id} 
                    className={`bg-white p-4 rounded-lg shadow-md ${pkg.isPopular ? 'border-2 border-secondary' : ''}`}
                  >
                    {pkg.isPopular && (
                      <div className="bg-secondary text-white px-3 py-1 rounded-full text-xs font-bold inline-block -mt-8">
                        MAIS POPULAR
                      </div>
                    )}
                    <h4 className="font-heading font-bold text-xl mb-2">{pkg.name}</h4>
                    <p className="text-3xl font-bold text-primary mb-2">
                      R$ {(pkg.price / 100).toFixed(2).replace('.', ',')}
                    </p>
                    <p className="text-gray-600 mb-4">
                      {pkg.cardCount} cartelas (R$ {((pkg.price / pkg.cardCount) / 100).toFixed(2).replace('.', ',')} cada)
                    </p>
                    <button
                      onClick={() => handleBuyPackage(pkg)}
                      className={`${pkg.isPopular ? 'bg-secondary hover:bg-blue-600' : 'bg-primary hover:bg-primary-dark'} text-white py-2 px-4 rounded-full cursor-pointer transition-colors w-full`}
                    >
                      Comprar
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Prizes Section */}
      <section id="premios" className="py-16 bg-neutral-dark text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Prêmios Incríveis</h2>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              Várias formas de ganhar e prêmios que são transferidos diretamente para sua conta!
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Prize 1 */}
            <div className="bg-neutral-900 rounded-lg p-6 text-center border border-primary">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="material-icons text-3xl">horizontal_rule</span>
              </div>
              <h3 className="font-heading font-bold text-xl mb-2">Linha Horizontal</h3>
              <p className="text-gray-300 mb-3">Complete qualquer linha horizontal na cartela</p>
              <p className="text-2xl font-bold text-primary">R$ 50,00</p>
            </div>
            
            {/* Prize 2 */}
            <div className="bg-neutral-900 rounded-lg p-6 text-center border border-secondary">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="material-icons text-3xl">vertical_align_center</span>
              </div>
              <h3 className="font-heading font-bold text-xl mb-2">Linha Vertical</h3>
              <p className="text-gray-300 mb-3">Complete qualquer linha vertical na cartela</p>
              <p className="text-2xl font-bold text-secondary">R$ 50,00</p>
            </div>
            
            {/* Prize 3 */}
            <div className="bg-neutral-900 rounded-lg p-6 text-center border border-accent">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4 text-neutral-dark">
                <span className="material-icons text-3xl">close</span>
              </div>
              <h3 className="font-heading font-bold text-xl mb-2">Diagonal</h3>
              <p className="text-gray-300 mb-3">Complete qualquer diagonal na cartela</p>
              <p className="text-2xl font-bold text-accent">R$ 75,00</p>
            </div>
            
            {/* Prize 4 */}
            <div className="bg-neutral-900 rounded-lg p-6 text-center border border-success">
              <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="material-icons text-3xl">grid_view</span>
              </div>
              <h3 className="font-heading font-bold text-xl mb-2">Cartela Completa</h3>
              <p className="text-gray-300 mb-3">Complete todos os números da cartela</p>
              <p className="text-2xl font-bold text-success">R$ 200,00</p>
            </div>
          </div>
          
          <div className="mt-16 bg-neutral-900 p-8 rounded-lg">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-heading font-bold">Super Prêmio Bingo Acumulado</h3>
              <p className="text-gray-300 mt-2">O prêmio especial que aumenta a cada rodada sem vencedor!</p>
            </div>
            
            <div className="flex flex-wrap justify-center items-center">
              <div className="text-center p-4">
                <p className="text-gray-300 mb-2">Valor Atual:</p>
                <div className="font-['Luckiest_Guy'] text-5xl text-accent mb-4">R$ 1.450,00</div>
                <p className="text-gray-400 text-sm">Aumenta R$ 50,00 a cada rodada sem vencedor</p>
              </div>
              
              <div className="h-40 w-px bg-gray-700 mx-8 hidden md:block"></div>
              
              <div className="text-center p-4">
                <p className="text-gray-300 mb-2">Próximo Sorteio:</p>
                <div className="font-bold text-2xl text-white mb-4">Domingo, 19:00h</div>
                <button className="bg-accent text-neutral-dark py-2 px-6 rounded-full inline-block font-bold hover:bg-yellow-400 transition-colors">
                  Lembrar-me
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-neutral-dark mb-4">
              Como Funciona o Pagamento
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Usamos PIX para garantir que seus pagamentos sejam rápidos, seguros e sem complicações!
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="mb-8">
                <h3 className="text-2xl font-heading font-bold mb-4 flex items-center">
                  <span className="material-icons text-primary mr-2">payments</span>
                  Pagamento Simples via PIX
                </h3>
                <p className="text-gray-600 mb-4">
                  Você pode comprar suas cartelas usando o PIX, o sistema de pagamentos instantâneos do Banco Central do Brasil.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="material-icons text-success mr-2 mt-1">check_circle</span>
                    <span>Pagamentos instantâneos 24/7</span>
                  </li>
                  <li className="flex items-start">
                    <span className="material-icons text-success mr-2 mt-1">check_circle</span>
                    <span>Sem taxas adicionais</span>
                  </li>
                  <li className="flex items-start">
                    <span className="material-icons text-success mr-2 mt-1">check_circle</span>
                    <span>Totalmente seguro</span>
                  </li>
                  <li className="flex items-start">
                    <span className="material-icons text-success mr-2 mt-1">check_circle</span>
                    <span>Confirmação automática</span>
                  </li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-2xl font-heading font-bold mb-4 flex items-center">
                  <span className="material-icons text-primary mr-2">verified</span>
                  Verificação de Pagamento
                </h3>
                <p className="text-gray-600 mb-4">
                  Após o pagamento, nosso sistema verifica automaticamente e libera suas cartelas em segundos!
                </p>
                <div className="bg-neutral-light p-4 rounded-lg">
                  <p className="text-sm text-gray-500 mb-2">Contatos para suporte de pagamento:</p>
                  <p className="flex items-center mb-2">
                    <span className="material-icons text-primary mr-2">email</span>
                    <span>gabrielastefa1@gmail.com</span>
                  </p>
                  <p className="flex items-center">
                    <span className="material-icons text-primary mr-2">support_agent</span>
                    <span>Suporte via WhatsApp (horário comercial)</span>
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-neutral-light p-8 rounded-lg shadow-md">
              <h3 className="text-xl font-heading font-bold mb-6 text-center">Exemplo de Pagamento PIX</h3>
              
              <div className="mb-6">
                <div className="bg-white p-4 rounded border border-gray-200">
                  <p className="text-center mb-2 font-bold">QR Code PIX</p>
                  {/* QR Code placeholder */}
                  <div className="w-48 h-48 mx-auto bg-white border-2 border-primary p-2 mb-4">
                    <div className="w-full h-full bg-white flex items-center justify-center">
                      <img 
                        src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=gabrielastefa1@gmail.com|50.00|Bingo+Gipsy"
                        alt="QR Code PIX exemplo" 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-500 mb-1">Chave PIX:</p>
                    <p className="font-mono bg-gray-100 p-2 rounded text-sm mb-3">gabrielastefa1@gmail.com</p>
                    <button className="text-secondary hover:text-blue-700 text-sm font-bold">
                      <span className="material-icons text-sm align-middle">content_copy</span> Copiar chave
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-300 pt-6">
                <h4 className="font-bold mb-4">Como enviar o comprovante:</h4>
                <div className="bg-white p-4 rounded border border-gray-200 mb-4">
                  <div className="flex items-center mb-2">
                    <span className="material-icons text-primary mr-2">file_upload</span>
                    <span className="font-bold">Envie seu comprovante</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">
                    Faça upload do screenshot do seu comprovante de pagamento para liberação imediata das cartelas.
                  </p>
                  <button className="bg-secondary text-white py-2 px-4 rounded text-center w-full cursor-pointer hover:bg-blue-600 transition-colors">
                    Enviar Comprovante
                  </button>
                </div>
                <p className="text-sm text-gray-500 text-center">
                  Suas cartelas serão liberadas após confirmação do pagamento.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Registration Section */}
      <section id="cadastro" className="py-16 bg-neutral-light">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2 bg-primary p-8 text-white">
                <h2 className="text-3xl font-heading font-bold mb-4">
                  Crie sua Conta Agora
                </h2>
                <p className="mb-6">
                  Cadastre-se e comece a jogar imediatamente! Jogos 24 horas por dia, todos os dias.
                </p>
                
                <div className="mb-6">
                  <h3 className="text-xl font-bold mb-3">Vantagens Exclusivas:</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <span className="material-icons mr-2">star</span>
                      <span>Jogos acontecendo 24 horas por dia</span>
                    </li>
                    <li className="flex items-start">
                      <span className="material-icons mr-2">star</span>
                      <span>Acesso instantâneo após o cadastro</span>
                    </li>
                    <li className="flex items-start">
                      <span className="material-icons mr-2">star</span>
                      <span>Pagamentos via PIX rápidos e seguros</span>
                    </li>
                    <li className="flex items-start">
                      <span className="material-icons mr-2">star</span>
                      <span>Prêmios transferidos diretamente para sua conta</span>
                    </li>
                  </ul>
                </div>
                
                <div className="hidden md:block">
                  <div className="flex space-x-4 mb-4">
                    {/* Animated bingo balls */}
                    <BingoBall letter="B" number={12} size="sm" />
                    <BingoBall letter="I" number={37} size="sm" />
                    <BingoBall letter="N" number={45} size="sm" />
                  </div>
                </div>
              </div>
              
              <div className="md:w-1/2 p-8">
                <RegisterForm />
              </div>
            </div>
          </div>
          
          {/* Testimonials */}
          <Testimonials />
        </div>
      </section>

      <Footer />
    </div>
  );
}
