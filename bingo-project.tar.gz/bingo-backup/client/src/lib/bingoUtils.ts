// Generate a random Bingo card
export function generateBingoCard(isPremium: boolean = false): number[][] {
  // Bingo card has 5 columns (B, I, N, G, O)
  // Each column has 5 numbers from a specific range
  const card: number[][] = [];

  // B column: 1-15
  const bColumn = generateRandomUniqueNumbers(1, 15, 5);
  card.push(bColumn);

  // I column: 16-30
  const iColumn = generateRandomUniqueNumbers(16, 30, 5);
  card.push(iColumn);

  // N column: 31-45 (with free space in the middle)
  const nColumn = generateRandomUniqueNumbers(31, 45, 4);
  // Insert the free space (represented as 0) in the middle
  nColumn.splice(2, 0, 0);
  card.push(nColumn);

  // G column: 46-60
  const gColumn = generateRandomUniqueNumbers(46, 60, 5);
  card.push(gColumn);

  // O column: 61-75
  const oColumn = generateRandomUniqueNumbers(61, 75, 5);
  card.push(oColumn);

  return card;
}

// Generate unique random numbers within a range
function generateRandomUniqueNumbers(min: number, max: number, count: number): number[] {
  const numbers: number[] = [];
  
  while (numbers.length < count) {
    const randomNum = Math.floor(Math.random() * (max - min + 1)) + min;
    if (!numbers.includes(randomNum)) {
      numbers.push(randomNum);
    }
  }
  
  return numbers;
}

// Check if a card has a winning pattern
export function checkWinningPattern(
  card: number[][],
  drawnNumbers: number[],
  patternType: 'line' | 'column' | 'diagonal' | 'full'
): boolean {
  switch (patternType) {
    case 'line':
      return checkHorizontalLines(card, drawnNumbers);
    case 'column':
      return checkVerticalLines(card, drawnNumbers);
    case 'diagonal':
      return checkDiagonals(card, drawnNumbers);
    case 'full':
      return checkFullCard(card, drawnNumbers);
    default:
      return false;
  }
}

// Check if any horizontal line is complete
function checkHorizontalLines(card: number[][], drawnNumbers: number[]): boolean {
  // For each row
  for (let row = 0; row < 5; row++) {
    let lineComplete = true;
    
    // Check each column in this row
    for (let col = 0; col < 5; col++) {
      const number = card[col][row];
      // Skip the free space
      if (number === 0) continue;
      
      if (!drawnNumbers.includes(number)) {
        lineComplete = false;
        break;
      }
    }
    
    if (lineComplete) return true;
  }
  
  return false;
}

// Check if any vertical line is complete
function checkVerticalLines(card: number[][], drawnNumbers: number[]): boolean {
  // For each column
  for (let col = 0; col < 5; col++) {
    let lineComplete = true;
    
    // Check each row in this column
    for (let row = 0; row < 5; row++) {
      const number = card[col][row];
      // Skip the free space
      if (number === 0) continue;
      
      if (!drawnNumbers.includes(number)) {
        lineComplete = false;
        break;
      }
    }
    
    if (lineComplete) return true;
  }
  
  return false;
}

// Check if any diagonal is complete
function checkDiagonals(card: number[][], drawnNumbers: number[]): boolean {
  // Check the main diagonal (top-left to bottom-right)
  let diagonal1Complete = true;
  for (let i = 0; i < 5; i++) {
    const number = card[i][i];
    // Skip the free space
    if (number === 0) continue;
    
    if (!drawnNumbers.includes(number)) {
      diagonal1Complete = false;
      break;
    }
  }
  
  if (diagonal1Complete) return true;
  
  // Check the other diagonal (bottom-left to top-right)
  let diagonal2Complete = true;
  for (let i = 0; i < 5; i++) {
    const number = card[i][4 - i];
    // Skip the free space
    if (number === 0) continue;
    
    if (!drawnNumbers.includes(number)) {
      diagonal2Complete = false;
      break;
    }
  }
  
  return diagonal2Complete;
}

// Check if the full card is complete
function checkFullCard(card: number[][], drawnNumbers: number[]): boolean {
  for (let col = 0; col < 5; col++) {
    for (let row = 0; row < 5; row++) {
      const number = card[col][row];
      // Skip the free space
      if (number === 0) continue;
      
      if (!drawnNumbers.includes(number)) {
        return false;
      }
    }
  }
  
  return true;
}

// Generate a random bingo ball number (1-75) that hasn't been drawn yet
export function getNextBingoBall(drawnNumbers: number[]): number {
  let ball: number;
  
  do {
    ball = Math.floor(Math.random() * 75) + 1;
  } while (drawnNumbers.includes(ball));
  
  return ball;
}

// Format price from cents to Brazilian Real
export function formatPrice(cents: number): string {
  return `R$ ${(cents / 100).toFixed(2).replace('.', ',')}`;
}

// Get the bingo ball color based on its column
export function getBingoBallColor(number: number): string {
  if (number <= 15) return "bg-primary"; // B
  if (number <= 30) return "bg-secondary"; // I
  if (number <= 45) return "bg-accent text-neutral-dark"; // N
  if (number <= 60) return "bg-success"; // G
  return "bg-error"; // O
}

// Get the bingo ball letter
export function getBingoBallLetter(number: number): string {
  if (number <= 15) return "B";
  if (number <= 30) return "I";
  if (number <= 45) return "N";
  if (number <= 60) return "G";
  return "O";
}
