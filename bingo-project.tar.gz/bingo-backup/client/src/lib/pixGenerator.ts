// Utility functions for generating PIX payment information

/**
 * Generate a PIX QR code image URL
 * This is a simple implementation for demonstration purposes
 * In a real application, you would use a PIX API/SDK to generate a proper QR code
 * 
 * @param email PIX key (email)
 * @param amount Amount in cents
 * @param description Payment description
 * @returns URL string for a QR code
 */
export function generatePixQRCodeURL(email: string, amount: number, description: string): string {
  // In a real implementation, you would call an actual PIX API
  // For this demo, we'll use a generic QR code generator
  
  // Format amount from cents to reais
  const formattedAmount = (amount / 100).toFixed(2);
  
  // Create a PIX payload (simplified)
  const pixData = `${email}|${formattedAmount}|${description}`;
  
  // Encode the data for URL
  const encodedData = encodeURIComponent(pixData);
  
  // Use a generic QR code API (for demonstration purposes only)
  return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodedData}`;
}

/**
 * Generate a mock PIX key representation with dashes for easy copying
 * @param email The email to format
 * @returns Formatted PIX key as a string
 */
export function formatPixKey(email: string): string {
  return email;
}

/**
 * Generate a random PIX transaction ID
 * This is for demo purposes only
 * @returns A random transaction ID string
 */
export function generatePixTransactionId(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  const length = 16;
  
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return result;
}
