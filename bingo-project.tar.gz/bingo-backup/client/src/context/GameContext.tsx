import React, { createContext, useContext, useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";

// Define the context type
interface GameContextType {
  drawnNumbers: number[];
  setDrawnNumbers: React.Dispatch<React.SetStateAction<number[]>>;
  lastDrawnNumber: number | null;
  setLastDrawnNumber: React.Dispatch<React.SetStateAction<number | null>>;
  isDrawing: boolean;
  setIsDrawing: React.Dispatch<React.SetStateAction<boolean>>;
}

// Create the context with default values
const GameContext = createContext<GameContextType>({
  drawnNumbers: [],
  setDrawnNumbers: () => {},
  lastDrawnNumber: null,
  setLastDrawnNumber: () => {},
  isDrawing: false,
  setIsDrawing: () => {},
});

// Custom hook to use the game context
export const useGameContext = () => useContext(GameContext);

// Provider component
export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [drawnNumbers, setDrawnNumbers] = useState<number[]>([]);
  const [lastDrawnNumber, setLastDrawnNumber] = useState<number | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  
  // Fetch active game data if any
  const { data: activeGame } = useQuery({
    queryKey: ['/api/games/active'],
    refetchInterval: 5000, // Refetch every 5 seconds to get updates
  });
  
  // Update state when active game data changes
  useEffect(() => {
    if (activeGame && activeGame.drawnNumbers && activeGame.drawnNumbers.length > 0) {
      setDrawnNumbers(activeGame.drawnNumbers);
      setLastDrawnNumber(activeGame.drawnNumbers[activeGame.drawnNumbers.length - 1]);
    }
  }, [activeGame]);
  
  // Provide the context value
  const contextValue: GameContextType = {
    drawnNumbers,
    setDrawnNumbers,
    lastDrawnNumber,
    setLastDrawnNumber,
    isDrawing,
    setIsDrawing,
  };
  
  return (
    <GameContext.Provider value={contextValue}>
      {children}
    </GameContext.Provider>
  );
};
