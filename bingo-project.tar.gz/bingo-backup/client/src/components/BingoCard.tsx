import { useState, useEffect } from "react";
import { formatPrice } from "@/lib/bingoUtils";

interface BingoCardProps {
  cardId: string;
  numbers: number[][]; // 5x5 grid of numbers
  markedNumbers?: number[];
  isPremium?: boolean;
  price: number;
  showPrice?: boolean;
}

export default function BingoCard({
  cardId,
  numbers,
  markedNumbers = [],
  isPremium = false,
  price,
  showPrice = true
}: BingoCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  // Convert to flat array for easier checking
  const flattenedMarkedNumbers = markedNumbers || [];
  
  // CSS classes based on props
  const cardClasses = `transform transition-transform duration-300 hover:scale-105 ${
    isPremium ? "border-2 border-accent" : ""
  }`;
  
  return (
    <div 
      className={`bingo-card bg-white rounded-lg p-4 shadow-md ${cardClasses}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {isPremium && (
        <div className="bg-accent text-neutral-dark px-3 py-1 rounded-full text-xs font-bold inline-block -mt-4 ml-2">
          CARTELA PREMIUM
        </div>
      )}
      
      <div className="bingo-header grid grid-cols-5 gap-1 mb-2 mt-2">
        <span className="text-primary font-['Luckiest_Guy'] text-xl">B</span>
        <span className="text-secondary font-['Luckiest_Guy'] text-xl">I</span>
        <span className="text-accent text-black font-['Luckiest_Guy'] text-xl">N</span>
        <span className="text-success font-['Luckiest_Guy'] text-xl">G</span>
        <span className="text-error font-['Luckiest_Guy'] text-xl">O</span>
      </div>
      
      <div className="grid grid-cols-5 gap-1">
        {/* B Column */}
        {numbers[0].map((number, rowIndex) => (
          <div
            key={`B-${rowIndex}`}
            className={`bingo-cell w-10 h-10 flex items-center justify-center font-bold border border-gray-200 ${
              flattenedMarkedNumbers.includes(number) ? "bg-primary text-white" : ""
            }`}
          >
            {number}
          </div>
        ))}
        
        {/* I Column */}
        {numbers[1].map((number, rowIndex) => (
          <div
            key={`I-${rowIndex}`}
            className={`bingo-cell w-10 h-10 flex items-center justify-center font-bold border border-gray-200 ${
              flattenedMarkedNumbers.includes(number) ? "bg-primary text-white" : ""
            }`}
          >
            {number}
          </div>
        ))}
        
        {/* N Column (with FREE space in the middle) */}
        {numbers[2].map((number, rowIndex) => (
          <div
            key={`N-${rowIndex}`}
            className={`bingo-cell w-10 h-10 flex items-center justify-center font-bold border border-gray-200 ${
              number === 0 
                ? "bg-accent text-neutral-dark" 
                : flattenedMarkedNumbers.includes(number) 
                  ? "bg-primary text-white" 
                  : ""
            }`}
          >
            {number === 0 ? "FREE" : number}
          </div>
        ))}
        
        {/* G Column */}
        {numbers[3].map((number, rowIndex) => (
          <div
            key={`G-${rowIndex}`}
            className={`bingo-cell w-10 h-10 flex items-center justify-center font-bold border border-gray-200 ${
              flattenedMarkedNumbers.includes(number) ? "bg-primary text-white" : ""
            }`}
          >
            {number}
          </div>
        ))}
        
        {/* O Column */}
        {numbers[4].map((number, rowIndex) => (
          <div
            key={`O-${rowIndex}`}
            className={`bingo-cell w-10 h-10 flex items-center justify-center font-bold border border-gray-200 ${
              flattenedMarkedNumbers.includes(number) ? "bg-primary text-white" : ""
            }`}
          >
            {number}
          </div>
        ))}
      </div>
      
      <div className="mt-4 text-center">
        <p className="text-gray-500 text-sm mb-2">Cartela {cardId}</p>
        {showPrice && (
          <p className="font-bold text-primary">{formatPrice(price)}</p>
        )}
        {isPremium && showPrice && (
          <p className="text-sm text-success">Prêmio 2x maior!</p>
        )}
      </div>
    </div>
  );
}
