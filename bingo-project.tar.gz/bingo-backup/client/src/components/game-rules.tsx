import BingoBall from "./BingoBall";

export default function GameRules() {
  return (
    <section id="como-jogar" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-neutral-dark mb-4">Como Jogar</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Nosso bingo online é fácil, divertido e você pode ganhar prêmios incríveis! Veja como funciona:
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Step 1 */}
          <div className="bg-neutral-light rounded-lg p-6 shadow-md text-center">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white mx-auto mb-4">
              <span className="material-icons text-3xl">looks_one</span>
            </div>
            <h3 className="text-xl font-heading font-bold mb-3">Cadastre-se</h3>
            <p className="text-gray-600">
              Crie sua conta e entre na lista de espera para ser um dos primeiros a jogar.
            </p>
          </div>
          
          {/* Step 2 */}
          <div className="bg-neutral-light rounded-lg p-6 shadow-md text-center">
            <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center text-white mx-auto mb-4">
              <span className="material-icons text-3xl">looks_two</span>
            </div>
            <h3 className="text-xl font-heading font-bold mb-3">Compre Cartelas</h3>
            <p className="text-gray-600">
              Adquira suas cartelas através de pagamento via PIX de forma rápida e segura.
            </p>
          </div>
          
          {/* Step 3 */}
          <div className="bg-neutral-light rounded-lg p-6 shadow-md text-center">
            <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center text-neutral-dark mx-auto mb-4">
              <span className="material-icons text-3xl">looks_3</span>
            </div>
            <h3 className="text-xl font-heading font-bold mb-3">Jogue e Ganhe!</h3>
            <p className="text-gray-600">
              Participe dos sorteios em tempo real e receba prêmios instantaneamente quando ganhar.
            </p>
          </div>
        </div>
        
        <div className="mt-16 text-center">
          <h3 className="text-2xl font-heading font-bold mb-6">Demonstração de Sorteio</h3>
          
          {/* Bingo drawing simulation */}
          <div className="relative max-w-xl mx-auto mb-8 p-6 bg-neutral-dark rounded-lg">
            <div className="flex flex-wrap justify-center gap-3 mb-6">
              <BingoBall number={18} />
              <BingoBall number={34} />
              <BingoBall number={52} />
              <BingoBall number={7} />
              <BingoBall number={63} />
            </div>
            <div className="text-center">
              <div className="inline-block py-3 px-8 bg-primary rounded-full text-white font-['Luckiest_Guy'] text-2xl animate-pulse">
                <span>Próximo em: 10s</span>
              </div>
            </div>
          </div>
          
          <div className="max-w-2xl mx-auto mt-12 p-6 bg-neutral-100 rounded-lg">
            <h4 className="text-xl font-heading font-bold mb-4">Regras Básicas</h4>
            <ul className="text-left space-y-3">
              <li className="flex items-start">
                <span className="material-icons text-primary mr-2 mt-1">check_circle</span>
                <span>Cada cartela tem 24 números + 1 espaço FREE no centro.</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-primary mr-2 mt-1">check_circle</span>
                <span>Os números são sorteados aleatoriamente de 1 a 75.</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-primary mr-2 mt-1">check_circle</span>
                <span>Complete uma linha, coluna, diagonal ou toda a cartela para ganhar.</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-primary mr-2 mt-1">check_circle</span>
                <span>O sistema verifica automaticamente quando você ganha.</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-primary mr-2 mt-1">check_circle</span>
                <span>Prêmios são transferidos diretamente para sua conta via PIX.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
