import { getBingoBallColor, getBingoBallLetter } from "@/lib/bingoUtils";

interface BingoBallProps {
  number: number | null;
  letter?: string | null;
  size?: "sm" | "md" | "lg";
  pulse?: boolean;
  className?: string;
  animationDelay?: number;
}

export default function BingoBall({
  number,
  letter = null,
  size = "md",
  pulse = false,
  className = "",
  animationDelay = 0
}: BingoBallProps) {
  // Determine letter if not provided
  const ballLetter = letter || (number ? getBingoBallLetter(number) : "B");
  
  // Determine color based on letter or number
  let colorClass = "";
  if (number) {
    colorClass = getBingoBallColor(number);
  } else {
    switch (ballLetter) {
      case "B": colorClass = "bg-primary"; break;
      case "I": colorClass = "bg-secondary"; break;
      case "N": colorClass = "bg-accent text-neutral-dark"; break;
      case "G": colorClass = "bg-success"; break;
      case "O": colorClass = "bg-error"; break;
      default: colorClass = "bg-primary";
    }
  }
  
  // Determine size class
  let sizeClass = "w-14 h-14 text-xl";
  if (size === "sm") {
    sizeClass = "w-10 h-10 text-base";
  } else if (size === "lg") {
    sizeClass = "w-20 h-20 text-3xl";
  }
  
  // Animation classes
  const animationClass = animationDelay > 0 
    ? `floating`
    : pulse ? "animate-pulse" : "";
  
  const animationStyle = animationDelay > 0 
    ? { animationDelay: `${animationDelay}s` }
    : {};
  
  return (
    <div
      className={`bingo-ball ${colorClass} ${sizeClass} ${animationClass} ${className} rounded-full flex items-center justify-center font-bold relative overflow-hidden shadow-inner`}
      style={animationStyle}
    >
      {number ? number : ballLetter}
      <div className="absolute top-1 left-2 w-3 h-3 bg-white/40 rounded-full"></div>
    </div>
  );
}

// Add CSS for floating animation to global CSS in index.css
const FloatingAnimation = `
@keyframes float {
  0%, 100% { transform: translateY(0); }
  50% { transform: translateY(-10px); }
}

.floating {
  animation: float 3s ease-in-out infinite;
}
`;

// We'll add this to the generated CSS file
document.head.appendChild(document.createElement('style')).innerHTML = FloatingAnimation;
