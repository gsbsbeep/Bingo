import { Link } from "wouter";
import BingoBall from "./BingoBall";

export default function Footer() {
  return (
    <footer className="bg-neutral-dark text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-6">
              <BingoBall letter="B" number={null} size="sm" className="mr-3" />
              <h2 className="text-2xl font-heading font-bold">Bingo Gipsy</h2>
            </div>
            <p className="text-gray-400 mb-4">
              O melhor bingo online do Brasil com prêmios reais e pagamentos instantâneos via PIX.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <span className="material-icons">facebook</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <span className="material-icons">whatshot</span>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <span className="material-icons">photo_camera</span>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <a href="#como-jogar" className="text-gray-400 hover:text-white transition-colors">
                  Como Jogar
                </a>
              </li>
              <li>
                <a href="#cartelas" className="text-gray-400 hover:text-white transition-colors">
                  Cartelas
                </a>
              </li>
              <li>
                <a href="#premios" className="text-gray-400 hover:text-white transition-colors">
                  Prêmios
                </a>
              </li>
              <li>
                <a href="#lista-espera" className="text-gray-400 hover:text-white transition-colors">
                  Lista de Espera
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Suporte</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                  Contato
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                  Termos de Uso
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                  Política de Privacidade
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Contato</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="material-icons mr-2 text-primary">email</span>
                <span className="text-gray-400">gabrielastefa1@gmail.com</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons mr-2 text-primary">support_agent</span>
                <span className="text-gray-400">Suporte via WhatsApp</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons mr-2 text-primary">schedule</span>
                <span className="text-gray-400">Seg-Sex: 9h às 18h</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-500">&copy; {new Date().getFullYear()} Bingo Gipsy Brasil. Todos os direitos reservados.</p>
          <p className="text-xs text-gray-600 mt-2">
            Este site é destinado a entretenimento e está em conformidade com a legislação brasileira.
          </p>
        </div>
      </div>
    </footer>
  );
}
