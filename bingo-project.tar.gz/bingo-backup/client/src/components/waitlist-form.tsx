import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertUserSchema } from "@shared/schema";
import { useLocation } from "wouter";

import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { CheckCircle } from "lucide-react";

// Extend the schema with any additional validation rules
const formSchema = insertUserSchema.extend({
  name: z.string().min(3, {
    message: "Nome deve ter pelo menos 3 caracteres.",
  }),
  email: z.string().email({
    message: "Endereço de email inválido.",
  }),
  phone: z.string().min(10, {
    message: "Telefone deve ter pelo menos 10 dígitos.",
  }),
  password: z.string().min(6, {
    message: "Senha deve ter pelo menos 6 caracteres.",
  }),
  consent: z.literal(true, {
    errorMap: () => ({ message: "Você precisa aceitar os termos." }),
  }),
});

type FormValues = z.infer<typeof formSchema>;

export default function RegisterForm() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [isSubmitSuccessful, setIsSubmitSuccessful] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      password: "",
      consent: true, // Corrigido para true como exigido pelo tipo
    },
  });

  const mutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const { consent, ...userData } = values;
      const response = await apiRequest("POST", "/api/users", {
        ...userData,
        role: "user",
        isActive: true
      });
      return response.json();
    },
    onSuccess: (data) => {
      setIsSubmitSuccessful(true);
      toast({
        title: "Cadastro realizado com sucesso!",
        description: "Sua conta foi criada. Você já pode acessar o Bingo Gipsy.",
        variant: "default",
      });
      // Redireciona para o dashboard após 2 segundos
      setTimeout(() => {
        navigate(`/dashboard/${data.id}`);
      }, 2000);
    },
    onError: (error) => {
      toast({
        title: "Erro ao cadastrar",
        description: error instanceof Error ? error.message : "Tente novamente mais tarde.",
        variant: "destructive",
      });
    },
  });

  function onSubmit(values: FormValues) {
    mutation.mutate(values);
  }

  if (isSubmitSuccessful) {
    return (
      <div className="text-center py-6">
        <div className="bg-success/20 p-6 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="h-12 w-12 text-success" />
        </div>
        <h3 className="text-2xl font-bold mb-2">Parabéns, {form.getValues().name}!</h3>
        <p className="text-gray-600 mb-4">
          Sua conta foi criada com sucesso! Você será redirecionado para seu painel em instantes.
        </p>
        <p className="font-bold text-primary">Prepare-se para jogar e ganhar!</p>
      </div>
    );
  }

  return (
    <div>
      <h3 className="text-2xl font-heading font-bold mb-6 text-neutral-dark">Crie sua Conta</h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome Completo</FormLabel>
                <FormControl>
                  <Input placeholder="Seu nome completo" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>E-mail</FormLabel>
                <FormControl>
                  <Input placeholder="seu@email.com" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Telefone (WhatsApp)</FormLabel>
                <FormControl>
                  <Input placeholder="(00) 00000-0000" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Senha</FormLabel>
                <FormControl>
                  <Input type="password" placeholder="Sua senha" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="consent"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>
                    Concordo com os termos de uso e política de privacidade do Bingo Gipsy.
                  </FormLabel>
                  <FormMessage />
                </div>
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            className="w-full font-bold text-lg"
            disabled={mutation.isPending}
          >
            {mutation.isPending ? (
              <span className="flex items-center">
                <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
                Processando...
              </span>
            ) : (
              <span className="flex items-center justify-center">
                <span className="material-icons mr-2">how_to_reg</span>
                Criar Conta
              </span>
            )}
          </Button>
        </form>
      </Form>
      
      <p className="text-sm text-gray-500 mt-4 text-center">
        Seus dados estão seguros e não serão compartilhados com terceiros.
      </p>
    </div>
  );
}
