import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import BingoBall from "./BingoBall";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  // Close menu when clicking on a link
  const handleNavLinkClick = () => {
    if (isMenuOpen) {
      setIsMenuOpen(false);
    }
  };

  const isHomePage = location === "/";

  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="flex items-center">
            <BingoBall letter="B" number={null} size="sm" className="mr-3" />
            <h1 className="text-2xl md:text-3xl font-heading font-bold">Bingo Gipsy</h1>
          </Link>
        </div>
        
        <nav className="hidden md:block">
          <ul className="flex space-x-6">
            {isHomePage ? (
              <>
                <li>
                  <a 
                    href="#como-jogar" 
                    className="hover:text-accent transition-colors"
                    onClick={handleNavLinkClick}
                  >
                    Como Jogar
                  </a>
                </li>
                <li>
                  <a 
                    href="#cartelas" 
                    className="hover:text-accent transition-colors"
                    onClick={handleNavLinkClick}
                  >
                    Cartelas
                  </a>
                </li>
                <li>
                  <a 
                    href="#premios" 
                    className="hover:text-accent transition-colors"
                    onClick={handleNavLinkClick}
                  >
                    Prêmios
                  </a>
                </li>
                <li>
                  <a 
                    href="#lista-espera" 
                    className="hover:text-accent transition-colors"
                    onClick={handleNavLinkClick}
                  >
                    Lista de Espera
                  </a>
                </li>
              </>
            ) : (
              <li>
                <Link 
                  href="/"
                  className="hover:text-accent transition-colors"
                  onClick={handleNavLinkClick}
                >
                  Página Inicial
                </Link>
              </li>
            )}
          </ul>
        </nav>
        
        <Button 
          variant="ghost" 
          size="icon" 
          className="md:hidden text-white" 
          onClick={toggleMenu}
        >
          {isMenuOpen ? <X /> : <Menu />}
        </Button>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-primary border-t border-primary-foreground/10">
          <div className="container mx-auto px-4 py-3">
            <ul className="space-y-3">
              {isHomePage ? (
                <>
                  <li>
                    <a 
                      href="#como-jogar" 
                      className="block py-2 hover:text-accent transition-colors"
                      onClick={handleNavLinkClick}
                    >
                      Como Jogar
                    </a>
                  </li>
                  <li>
                    <a 
                      href="#cartelas" 
                      className="block py-2 hover:text-accent transition-colors"
                      onClick={handleNavLinkClick}
                    >
                      Cartelas
                    </a>
                  </li>
                  <li>
                    <a 
                      href="#premios" 
                      className="block py-2 hover:text-accent transition-colors"
                      onClick={handleNavLinkClick}
                    >
                      Prêmios
                    </a>
                  </li>
                  <li>
                    <a 
                      href="#lista-espera" 
                      className="block py-2 hover:text-accent transition-colors"
                      onClick={handleNavLinkClick}
                    >
                      Lista de Espera
                    </a>
                  </li>
                </>
              ) : (
                <li>
                  <Link 
                    href="/"
                    className="block py-2 hover:text-accent transition-colors"
                    onClick={handleNavLinkClick}
                  >
                    Página Inicial
                  </Link>
                </li>
              )}
            </ul>
          </div>
        </div>
      )}
    </header>
  );
}
