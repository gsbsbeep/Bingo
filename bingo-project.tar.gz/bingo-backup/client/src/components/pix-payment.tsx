import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatPrice } from "@/lib/bingoUtils";
import { generatePixQRCodeURL } from "@/lib/pixGenerator";
import { useToast } from "@/hooks/use-toast";

interface PixPaymentProps {
  pixKey: string;
  amount: number;
  onProofSubmit: (proofUrl: string) => void;
  status: "pending" | "processing" | "completed" | "failed";
}

export default function PixPayment({
  pixKey,
  amount,
  onProofSubmit,
  status
}: PixPaymentProps) {
  const { toast } = useToast();
  const [isClipboardCopied, setIsClipboardCopied] = useState(false);
  const [fileSelected, setFileSelected] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // QR Code URL for PIX payment
  const qrCodeUrl = generatePixQRCodeURL(pixKey, amount, "Bingo Gipsy - Compra de Cartelas");
  
  // Copy PIX key to clipboard
  const handleCopyPixKey = () => {
    navigator.clipboard.writeText(pixKey)
      .then(() => {
        setIsClipboardCopied(true);
        toast({
          title: "Chave PIX copiada!",
          description: "A chave PIX foi copiada para a área de transferência.",
          variant: "success",
        });
        
        setTimeout(() => {
          setIsClipboardCopied(false);
        }, 3000);
      })
      .catch(() => {
        toast({
          title: "Erro ao copiar",
          description: "Não foi possível copiar a chave PIX.",
          variant: "destructive",
        });
      });
  };
  
  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setFileSelected(true);
    } else {
      setFileSelected(false);
    }
  };
  
  // Handle file upload submission
  const handleSubmitProof = () => {
    // In a real application, we would upload the file to a server
    // For this demo, we'll simulate the upload with a dummy URL
    
    // Check if we have a file
    if (!fileInputRef.current?.files?.length) {
      toast({
        title: "Nenhum arquivo selecionado",
        description: "Por favor, selecione um comprovante de pagamento.",
        variant: "destructive",
      });
      return;
    }
    
    // Simulate file upload
    // In a real app, you would use FormData to upload the file
    const file = fileInputRef.current.files[0];
    const mockProofUrl = `https://example.com/proof/${Date.now()}_${file.name}`;
    
    // Call the callback with the URL
    onProofSubmit(mockProofUrl);
  };
  
  return (
    <div className="space-y-6">
      <div className="bg-white p-4 rounded border border-gray-200">
        <p className="text-center mb-2 font-bold">QR Code PIX</p>
        <div className="w-48 h-48 mx-auto bg-white border-2 border-primary p-2 mb-4">
          <div className="w-full h-full bg-white flex items-center justify-center">
            <img 
              src={qrCodeUrl}
              alt="QR Code PIX" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
        <div className="text-center">
          <p className="text-sm text-gray-500 mb-1">Chave PIX:</p>
          <p className="font-mono bg-gray-100 p-2 rounded text-sm mb-3">{pixKey}</p>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-secondary hover:text-blue-700 text-sm font-bold"
            onClick={handleCopyPixKey}
          >
            <span className="material-icons text-sm align-middle mr-1">content_copy</span> 
            {isClipboardCopied ? "Copiado!" : "Copiar chave"}
          </Button>
        </div>
      </div>
      
      <div className="bg-muted/50 p-4 rounded mb-4">
        <p className="text-center font-medium mb-3">Valor a Pagar:</p>
        <p className="text-center text-2xl font-bold text-primary">{formatPrice(amount)}</p>
      </div>
      
      <div className="border-t border-gray-300 pt-6">
        <h4 className="font-bold mb-4">Como enviar o comprovante:</h4>
        <div className="bg-white p-4 rounded border border-gray-200 mb-4">
          <div className="flex items-center mb-2">
            <span className="material-icons text-primary mr-2">file_upload</span>
            <span className="font-bold">Envie seu comprovante</span>
          </div>
          <p className="text-sm text-gray-600 mb-4">
            Faça upload do screenshot do seu comprovante de pagamento para liberação imediata das cartelas.
          </p>
          
          <div className="space-y-4">
            <div className="grid w-full max-w-sm items-center gap-1.5">
              <Label htmlFor="proof-upload">Selecione o arquivo do comprovante</Label>
              <Input 
                id="proof-upload" 
                type="file" 
                accept="image/*"
                ref={fileInputRef}
                onChange={handleFileChange}
                disabled={status !== "pending"}
              />
            </div>
            
            <Button 
              className="w-full"
              onClick={handleSubmitProof}
              disabled={!fileSelected || status !== "pending"}
            >
              {status === "processing" ? (
                <span className="flex items-center">
                  <span className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></span>
                  Processando...
                </span>
              ) : (
                "Enviar Comprovante"
              )}
            </Button>
          </div>
        </div>
        <p className="text-sm text-gray-500 text-center">
          Suas cartelas serão liberadas após confirmação do pagamento.
        </p>
      </div>
    </div>
  );
}
