export default function Testimonials() {
  // Sample testimonial data
  const testimonials = [
    {
      name: "Maria Silva",
      rating: 5,
      text: "Participei da fase de testes e fiquei impressionada com a qualidade do jogo. A interface é muito fácil de usar e os prêmios são pagos rapidamente!",
      color: "bg-primary",
    },
    {
      name: "João Pereira",
      rating: 4.5,
      text: "Ganhei R$ 200 logo na primeira semana! O sistema de verificação de vitórias é automático e muito eficiente. Recomendo!",
      color: "bg-secondary",
    },
    {
      name: "Ana Costa",
      rating: 5,
      text: "A melhor parte é poder jogar direto do celular! Não perco mais nenhum sorteio e o pagamento via PIX é super rápido e seguro.",
      color: "bg-accent",
    }
  ];

  return (
    <div className="mt-16">
      <h3 className="text-2xl font-heading font-bold text-center mb-8">O Que Dizem Sobre Nós</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {testimonials.map((testimonial, index) => (
          <div key={index} className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center mb-4">
              <div className={`w-12 h-12 ${testimonial.color} rounded-full mr-4`}></div>
              <div>
                <h4 className="font-bold">{testimonial.name}</h4>
                <div className="flex text-accent">
                  {Array.from({ length: Math.floor(testimonial.rating) }).map((_, i) => (
                    <span key={i} className="material-icons">star</span>
                  ))}
                  {testimonial.rating % 1 !== 0 && (
                    <span className="material-icons">star_half</span>
                  )}
                </div>
              </div>
            </div>
            <p className="text-gray-600">{testimonial.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
